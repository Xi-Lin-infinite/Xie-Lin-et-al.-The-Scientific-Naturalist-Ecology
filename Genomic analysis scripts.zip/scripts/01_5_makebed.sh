#!/bin/bash
#SBATCH -c 24
#SBATCH --mem=24G
#SBATCH -J make_bed
#SBATCH --output=slurm-makebed-%j.out
#SBATCH --error=slurm-makebed-%j.err

job_path=/BIGDATA1/sysuls_yliu_1/boyaxie/vcf

module load vcftools

# make map
vcftools --vcf ${job_path}/9WFP.combined.filterpass2.snp.recode.vcf --plink --out ${job_path}/9WFP.combined.filterpass2.snp.recode
# make bed
"/BIGDATA1/sysuls_yliu_1/chenqing/soft/plink" --vcf ${job_path}/9WFP.combined.filterpass2.snp.recode.vcf --make-bed --set-missing-var-ids @_# --out ${job_path}/9WFP.combined.filterpass2.snp.recode --allow-extra-chr
