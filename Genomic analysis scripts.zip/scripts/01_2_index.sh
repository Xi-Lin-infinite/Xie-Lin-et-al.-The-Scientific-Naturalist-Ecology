#!/bin/bash

module load samtools
module load bwa

cd /BIGDATA1/sysuls_yliu_1/boyaxie/ref

bwa index -a bwtsw WFP.genome.v1.fas
samtools faidx WFP.genome.v1.fas 
samtools dict WFP.genome.v1.fas > WFP.genome.v1.dict