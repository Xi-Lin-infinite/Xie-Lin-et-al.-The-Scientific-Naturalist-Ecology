#!/bin/bash
#SBATCH -c 24
#SBATCH --mem=24G
#SBATCH -J sexratio
#SBATCH --output=slurm-sexratio-%j.out
#SBATCH --error=slurm-sexratio-%j.err

module load samtools

mkdir /BIGDATA1/sysuls_yliu_1/boyaxie/vcf/sex_ratio

bam_path=/BIGDATA1/sysuls_yliu_1/boyaxie/vcf/gvcf
sex_ratio_path=/BIGDATA1/sysuls_yliu_1/boyaxie/vcf/sex_ratio
sample=(1 2 3 4 5 6 M F1 F2)

for i in "${sample[@]}"; do

samtools coverage $bam_path/${i}_sort.rmdup.bam -o ${sex_ratio_path}/${i}}.coverage.txt

done