#!/bin/sh

# ******************************************
# 0. User settings 
# ******************************************

outdir=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/vcf/gvcf

# Number of threads. You can get the number of cpu cores by running nproc  
nt=24	

# Sample name and read group name. 
# It is important to assign meaningful names in actual cases.
# It is particularly important to assign different read group names 
# for each lane, when you need to combine results from different lanes from later on.
group="WFP"
#sample=(F1 F2 M 1 2 3 4 5 6)
sample=(4)

for s in "${sample[@]}"; do

# Log file 
logfile="$outdir/quick_start_${s}_$(date +"%Y%m%d%H%M").log"

#SAMPLE PATH
DIR=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/fastp

# there is no need to modify the rest of the script
# ******************************************
# 0. input locations
# ******************************************

# Test if location of the Sentieon installation directory is set
if [ -z "$SENTIEON_INSTALL_DIR" ]; then
	echo "Need to set SENTIEON_INSTALL_DIR environment variable."
	exit 1
fi

# Sequencing platform. Only Illumina supported.
pl="ILLUMINA" #platform

#SOURCE="$0"
#while [ -h "$SOURCE" ]; do 			# resolve $SOURCE until the file is no longer a symlink
#  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
#  SOURCE="$(readlink "$SOURCE")"
#  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
#done
#DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
#DIR=/BIGDATA1/app/sentieon/quick_start


set -x
exec 2>$logfile

# Input pair-ended Illumina fastq files 
fastq_1=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/fastp/${s}.R1.fq.gz
fastq_2=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/fastp/${s}.R2.fq.gz

# Fasta reference file
fasta=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/ref/WFP.genome.v1.fa


# ******************************************
# 1. Mapping reads with BWA-MEM. Output coordinate-sorted BAM file.
# ******************************************
start_time_mod=$(date +%s)
$SENTIEON_INSTALL_DIR/bin/bwa mem -M -R "@RG\tID:$group\tSM:${s}\tPL:$pl" -t $nt $fasta $fastq_1 $fastq_2 | $SENTIEON_INSTALL_DIR/bin/sentieon util sort -o $outdir/${s}_sorted.bam -t $nt --sam2bam -i -
end_time_mod=$(date +%s)
if [ "$OSTYPE" = "darwin"* ]; then start_date=$(date -j -f "%s" $start_time_mod); else start_date=$(date -d @$start_time_mod); fi
if [ "$OSTYPE" = "darwin"* ]; then end_date=$(date -j -f "%s" $end_time_mod); else end_date=$(date -d @$end_time_mod); fi
echo "Module BWA Started: "$start_date"; Ended: "$end_date"; Elapsed time: "$(($end_time_mod - $start_time_mod))" sec">>$logfile

# ******************************************
# 2. Metrics
#
# Produces Picard standard metrics of the input sequence and alignment. 
# ******************************************
start_time_mod=$(date +%s)
$SENTIEON_INSTALL_DIR/bin/sentieon driver -r $fasta -t $nt -i $outdir/${s}_sorted.bam --algo MeanQualityByCycle $outdir/${s}_mq_metrics.txt --algo QualDistribution $outdir/${s}_qd_metrics.txt --algo GCBias --summary $outdir/${s}_gc_summary.txt $outdir/${s}_gc_metrics.txt --algo AlignmentStat $outdir/${s}_aln_metrics.txt --algo InsertSizeMetricAlgo $outdir/${s}_is_metrics.txt 
$SENTIEON_INSTALL_DIR/bin/sentieon plot metrics -o $outdir/${s}_metrics_report.pdf gc=$outdir/${s}_gc_metrics.txt qd=$outdir/${s}_qd_metrics.txt mq=$outdir/${s}_mq_metrics.txt isize=$outdir/${s}_is_metrics.txt 
end_time_mod=$(date +%s)
if [ "$OSTYPE" = "darwin"* ]; then start_date=$(date -j -f "%s" $start_time_mod); else start_date=$(date -d @$start_time_mod); fi
if [ "$OSTYPE" = "darwin"* ]; then end_date=$(date -j -f "%s" $end_time_mod); else end_date=$(date -d @$end_time_mod); fi
echo "Module metrics Started: "$start_date"; Ended: "$end_date"; Elapsed time: "$(($end_time_mod - $start_time_mod))" sec">>$logfile

# ******************************************
# 3. Remove Duplicate Reads
#
# This step will mark and remove duplicates.
# If only marking without removal is desired, remove -rmdup option in the second command.
# ******************************************
start_time_mod=$(date +%s)
$SENTIEON_INSTALL_DIR/bin/sentieon driver  -t $nt -i $outdir/${s}_sorted.bam --algo LocusCollector --fun score_info $outdir/${s}_score.txt
$SENTIEON_INSTALL_DIR/bin/sentieon driver  -t $nt -i $outdir/${s}_sorted.bam --algo Dedup --rmdup --score_info $outdir/${s}_score.txt --metrics $outdir/${s}_dedup_metrics.txt $outdir/${s}_sort.rmdup.bam 
end_time_mod=$(date +%s)
if [ "$OSTYPE" = "darwin"* ]; then start_date=$(date -j -f "%s" $start_time_mod); else start_date=$(date -d @$start_time_mod); fi
if [ "$OSTYPE" = "darwin"* ]; then end_date=$(date -j -f "%s" $end_time_mod); else end_date=$(date -d @$end_time_mod); fi
echo "Module dedup Started: "$start_date"; Ended: "$end_date"; Elapsed time: "$(($end_time_mod - $start_time_mod))" sec">>$logfile

# ******************************************
# 7c. HC Variant caller generating GVCF
# ******************************************
start_time_mod=$(date +%s)
$SENTIEON_INSTALL_DIR/bin/sentieon driver -r $fasta  -t $nt -i $outdir/${s}_sort.rmdup.bam --algo Haplotyper --emit_mode gvcf $outdir/${s}_output-hc.g.vcf
end_time_mod=$(date +%s)
if [ "$OSTYPE" = "darwin"* ]; then start_date=$(date -j -f "%s" $start_time_mod); else start_date=$(date -d @$start_time_mod); fi
if [ "$OSTYPE" = "darwin"* ]; then end_date=$(date -j -f "%s" $end_time_mod); else end_date=$(date -d @$end_time_mod); fi
echo "Module HC generating GVCF Started: "$start_date"; Ended: "$end_date"; Elapsed time: "$(($end_time_mod - $start_time_mod))" sec">>$logfile

done
