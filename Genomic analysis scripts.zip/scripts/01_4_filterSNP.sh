#!/bin/bash

#SBATCH -c 24
#SBATCH --mem=24G
#SBATCH -p rhenv
#SBATCH -J filter
#SBATCH --output=slurm-filter-%j.out
#SBATCH --error=slurm-filter-%j.err

echo ==========selectSNP starts at `date`==========

module load GATK/4.1.4.1
module load bcftools
module load vcftools

ref=/BIGDATA1/sysuls_yliu_1/boyaxie/ref/WFP.genome.v1.fa
job_path=/BIGDATA1/sysuls_yliu_1/boyaxie/vcf

######################
## 1. GATK Filter   ##
######################
echo 1. GATK Filter

##select variants
# yhrun -N 1 -n 1 gatk SelectVariants -R ${ref} -V ${job_path}/9WFP.combined.vcf -select-type SNP --exclude-non-variants -O ${job_path}/9WFP.combined.raw.snp

##filter variants
# gatk VariantFiltration -R ${ref} -V ${job_path}/9WFP.combined.raw.snp --filter-name snpfilt --filter-expression 'QD < 2.0 || FS > 60.0 || MQ <40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0' -O ${job_path}/9WFP.combined.filter.snp.vcf

# #grep filteredpass
# egrep '#|PASS' ${job_path}/9WFP.combined.filter.snp.vcf > ${job_path}/9WFP.combined.filterpass.snp.vcf

# statics
# yhrun -N 1 -n 1 bcftools stats ${job_path}/9WFP.combined.filterpass.snp.vcf > ${job_path}/9WFP.combined.filterpass.snp.bcf.stat

##########################
## 2. vcftools Filter   ##
##########################
echo 2. vcftools Filter

module load vcftools
module load bcftools

bgzip ${job_path}/9WFP.combined.filterpass.snp.vcf

vcftools --gzvcf ${job_path}/9WFP.combined.filterpass.snp.vcf.gz --max-missing 0.8 --mac 3 --minQ 30 --min-meanDP 3 --max-meanDP 100 --hwe 0.01 --recode --recode-INFO-all --out ${job_path}/9WFP.combined.filterpass2.snp

###################
## 3. LD filter  ##
###################
echo 3. LD filter

module load bcftools

bcftools +prune -m 0.2 ${job_path}//9WFP.combined.filterpass2.snp.recode.vcf -Ov -o ${job_path}//9WFP.combined.filterpass2.snp.LD0.2.vcf

echo ==========selectSNP ends at `date`==========