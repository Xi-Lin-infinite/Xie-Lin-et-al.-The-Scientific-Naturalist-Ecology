#!/bin/bash

#SBATCH	-p mars 
#SBATCH	-J fastp_plus
#SBATCH	-c 16
#SBATCH	--mem=24G
#SBATCH	--output=slurm-fastp-%j.out
#SBATCH	--error=slurm-fastp-%j.err

in_path=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/sequencing_data
out_path=/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/boyaxie/fastp

/HOME/sysuls_yliu/sysuls_yliuxy_1/HDD_POOL/software/fastp	-i ${in_path}/sysb010317_R1.fq.gz -I ${in_path}/sysb010317_R2.fq.gz -o ${out_path}/E050-1.R1.fq.gz -O ${out_path}/E050-1.R2.fq.gz
/HOME/sysuls_yliu/sysuls_yliuxy_1/HDD_POOL/software/fastp	-i ${in_path}/sysb010318_R1.fq.gz  -I ${in_path}/sysb010318_R2.fq.gz -o ${out_path}/E050-2.R1.fq.gz -O ${out_path}/E050-2.R2.fq.gz

#/HOME/sysuls_yliu/sysuls_yliuxy_1/HDD_POOL/software/fastp	-i /XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/hoheiman/cleandata/Aerodramus_fuciphagus/PM-XS01KF2024010284-48/Rawdata/DZD2/DZD2_R1.fq.gz -I /XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/hoheiman/cleandata/Aerodramus_fuciphagus/PM-XS01KF2024010284-48/Rawdata/DZD2/DZD2_R2.fq.gz -o ${out_path}/DZD02.R1.fq.gz -O ${out_path}/DZD02.R2.fq.gz
