#!/bin/sh
nt=24	
if [ -z "$SENTIEON_INSTALL_DIR" ]; then
	echo "Need to set SENTIEON_INSTALL_DIR environment variable."
	exit 1
fi

pl="ILLUMINA"
$SENTIEON_INSTALL_DIR/bin/sentieon driver -r /BIGDATA1/sysuls_yliu_1/boyaxie/ref/WFP.genome.v1.fas --algo GVCFtyper /BIGDATA1/sysuls_yliu_1/boyaxie/vcf/9WFP.combined.vcf /BIGDATA1/sysuls_yliu_1/boyaxie/vcf/gvcf/*.vcf

