#! /usr/bin/perl
use warnings;
use strict;

my $file_path = "/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/v3_kp_wfp/01.sentieon/24nd.lst";
open IN, $file_path or die "Cannot open file: $!";
my @name;

while(my $line=<IN>){
  chomp($line);
  my @aa=split/\s+/,$line;
  my $sample=$aa[0];
  push @name,$sample;
  open my $OUT,">", "/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/v3_kp_wfp/01.sentieon/work/$sample.sh" or die "Cannot open file: $!";
  print $OUT "/XYFS01/HDD_POOL/sysuls_yliu/sysuls_yliuxy_1/niuxiaotong/v3_kp_wfp/01.sentieon/01.gvcf.sh $sample $aa[1] $aa[2]";
  close $OUT;
}

