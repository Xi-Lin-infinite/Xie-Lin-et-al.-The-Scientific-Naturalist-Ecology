#!/bin/bash
#SBATCH -c 24
#SBATCH --mem=24G
#SBATCH -J king
#SBATCH --output=slurm-king-%j.out
#SBATCH --error=slurm-king-%j.err

out_path=/BIGDATA1/sysuls_yliu_1/boyaxie/kinship
in_path=/BIGDATA1/sysuls_yliu_1/boyaxie/vcf

/BIGDATA1/sysuls_yliu_1/software/king -b $in_path/9WFP.combined.filterpass2.snp.recode.bed --kinship


